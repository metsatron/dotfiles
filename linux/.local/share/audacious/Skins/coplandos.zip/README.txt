[ SKIN INFO ]

SKIN NAME: CoplandOS
SKIN VERSION: 1.0
DATE CREATED: April 17, 2002
SKIN DESIGNER: Maciej Delmanowski
EMAIL: harnir@post.pl
SKIN GRAPHICS BY: Maciej Delmanowski


[ DESIGNER NOTES ]

This skin is based on a 'Copland OS Enterprise' logo, computer OS used in
anime called "Serial Experiments Lain', and is best viewed with that picture
in background. You can find it on several Internet sites. If you cannot find
that particular image and want it, send me email, so I can mail it to you.

I don't know right now (17.04.2002), who is the author of that picture. If
you know him (or maybye you're the author) send me a contact to him, so I
can ask him to include his great work in this skin package.

I hope that buttons are recognizeable and self-explanatory. Someone might
ask: 'why there is no CoplandOS logo on skin?' Well, I think that putting
CoplandOS logo everywhere is little stupid :) You can compare it to putting
in each Windows program a Windows logo... One logo on your desktop is
good enough.

If you like this skin and like SEL, send me an email. I have plans for
making similar skins for other programs on Linux, like GTK+ or GKrellM.

Thanks for downolading this skin, I hope you will enjoy it :)

Maciej Delmanowski
harnir@post.pl
