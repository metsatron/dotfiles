LFU Grey for Audacious

by: Svetoslav Stefanov <lfu.project84@gmail.com>


This theme is based on Ana for XMMS: http://www.gnome-look.org/content/show.php/Ana+XMMS?content=19537&PHPSESSID=02d8b02f779211f2ca7af2f52002d1cb
